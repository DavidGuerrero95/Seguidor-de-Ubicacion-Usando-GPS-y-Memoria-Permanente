#ifndef _GPIO_H
#define _GPIO_H

void gpio_init_outputs(uint outputs[]);
void gpio_init_inputs(uint inputs[]);


#endif