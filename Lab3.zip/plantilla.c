#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "plantilla.h"

bool imprimir_plantilla1(void){
    printf(LINEA1,COMILLAS,COMILLAS,COMILLAS,COMILLAS,COMILLAS,COMILLAS,COMILLAS,COMILLAS);
}

bool imprimir_plantilla2(void){
    printf(LINEA2);
}

bool imprimir_plantilla3(void){
    printf(LINEA3);
}
